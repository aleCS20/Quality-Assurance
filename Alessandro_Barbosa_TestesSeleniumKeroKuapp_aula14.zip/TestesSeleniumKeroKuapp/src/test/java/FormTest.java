import PageObjects.FormPage;
import PageObjects.LoginSucess;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static org.testng.AssertJUnit.assertTrue;

public class FormTest {
    private WebDriver driver;
    //teste inicial para abrir o navegador e acessar a página para teste
    @BeforeTest
    public void setUp(){
        driver = new FirefoxDriver();
        driver.get("https://the-internet.herokuapp.com/login");
    }
    //teste com os dados a serem passados como parâmetros ao formulário
    @Test
    public void testeLogin(){
        FormPage formPage = new FormPage(driver);
        LoginSucess login = new LoginSucess(driver);

        formPage.enterUserName("tomsmith");
        formPage.enterPassword("SuperSecretPassword!");
        formPage.clickButton();
        //assertTrue para verificar o conteúdo que está na página/texto
        assertTrue(login.getMessage().contains("You logged into a secure area!"));
    }

    //teste final do navegador para encerramento
    @AfterTest
    public void tearDown(){
        driver.quit();
    }
}
