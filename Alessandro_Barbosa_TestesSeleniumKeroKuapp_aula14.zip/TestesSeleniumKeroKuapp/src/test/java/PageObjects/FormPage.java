package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FormPage {
    private WebDriver driver;
    //criando o construtor da classe
    public FormPage(WebDriver driver) {
        this.driver = driver;
    }
    //método para pegar o nome do usuário para login da página e mapear
    public void enterUserName(String name){
        driver.findElement(By.id("username")).sendKeys(name);
    }
    //método para o password do usuário para ser mapeado
    public void enterPassword(String password){
        driver.findElement(By.id("password")).sendKeys(password);
    }
    //método para mapear o botão de login
    public void clickButton(){
        driver.findElement(By.xpath("/html/body/div[2]/div/div/form/button")).click();
    }

}
