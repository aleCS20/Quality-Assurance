package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginSucess {
    WebDriver driver;
    String message;
    //construtor
    public LoginSucess(WebDriver driver) {
        this.driver = driver;
    }

    //mapeando o elemento do texto da página após realizar login
    By heading = By.xpath("//*[@id=\"flash\"]");

    //método para pegar o texto e retornar a mensagem e o texto correspondente
    public String getMessage(){
        message = driver.findElement(heading).getText();
        return message;
    }

}
