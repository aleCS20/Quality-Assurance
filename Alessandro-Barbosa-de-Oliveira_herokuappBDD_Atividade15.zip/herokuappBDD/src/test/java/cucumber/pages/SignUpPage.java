package cucumber.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.time.Duration;

public class SignUpPage extends BasePage {

    public SignUpPage() {
        this.driver = new FirefoxDriver();
        this.driver.get("https://the-internet.herokuapp.com/login");
        this.driver.manage().timeouts()
                .implicitlyWait(Duration.ofSeconds(2))
                .pageLoadTimeout(Duration.ofSeconds(10));
    }
    public void preencherCamposXpath(String xpath, String texto){
        driver.findElement(By.xpath(xpath)).sendKeys(texto);
    }
    public void clicarButtonXpath(String xpath){
        driver.findElement(By.xpath(xpath)).click();
    }
    public boolean paginaCorreta(String urlEsperada){
        return driver.getCurrentUrl().equals(urlEsperada);
    }
    public boolean verificarTextoPorXpath(String xpath, String string){
        return driver.findElement(By.xpath(xpath)).getText().equals(string);
    }
}
