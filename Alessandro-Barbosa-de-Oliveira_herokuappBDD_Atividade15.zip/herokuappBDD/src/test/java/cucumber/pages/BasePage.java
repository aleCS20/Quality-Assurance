package cucumber.pages;

import org.openqa.selenium.firefox.FirefoxDriver;

public class BasePage {
    protected FirefoxDriver driver;
}
