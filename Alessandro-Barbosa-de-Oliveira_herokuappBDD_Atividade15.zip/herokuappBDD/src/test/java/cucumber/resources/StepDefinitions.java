package cucumber.resources;

import cucumber.pages.SignUpPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
//import java.util.Random;

public class StepDefinitions {
    private SignUpPage signUpPage;
    //private Random rand;

    @Given("User is on Homepage")
    public void user_is_on_homepage() {
        this.signUpPage = new SignUpPage();
    }

    @When("User enters a name on name field")
    public void user_enters_a_name_on_name_field() {
        signUpPage.preencherCamposXpath("/html/body/div[2]/div/div/form/div[1]/div/input","tomsmith");
    }

    @When("User enters a password on password field")
    public void user_enters_a_password_on_password_field() {
        signUpPage.preencherCamposXpath("/html/body/div[2]/div/div/form/div[2]/div/input", "SuperSecretPassword!");
    }

    @When("User clicks on the login button")
    public void user_clicks_on_the_login_button() {
        signUpPage.clicarButtonXpath("/html/body/div[2]/div/div/form/button");
    }

    @Then("User should be redirectioned to SignUp page")
    public void user_should_be_redirectioned_to_sign_up_page() {
       signUpPage.paginaCorreta("https://the-internet.herokuapp.com/secure");
       signUpPage.verificarTextoPorXpath("/html/body/div[1]/div/div", "You logged into a secure area!");
    }
}
