import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Random;

public class Cadastro {
    private WebDriver navegador;

    @BeforeTest
    public void setUp(){
        navegador = new FirefoxDriver();
        navegador.get("https://automationexercise.com/login");
    }

    @Test
    public void firefoxTest(){
        //gerar número aleatório para o email
        Random gerarEmail = new Random();

        //Criar formulário
        WebElement loginParaCriarUsuario = navegador.findElement(By.className("signup-form"));

        //Preencher o campo Nome
        loginParaCriarUsuario.findElement(By.name("name")).sendKeys("nomeCurso");

        //Preencher o campo Email
        loginParaCriarUsuario.findElement(By.name("email")).sendKeys("user_email_"+gerarEmail.nextInt(1001)+"@teste.com");

        //Clicar no botão signup
        navegador.findElement(By.xpath("/html/body/section/div/div/div[3]/div/form/button")).click();

        //formulario de cadastro
        WebElement cadastro = navegador.findElement(By.id("form"));

        cadastro.findElement(By.id("id_gender1")).click();
        cadastro.findElement(By.id("password")).sendKeys("123456");
        cadastro.findElement(By.xpath("//*[@id=\"days\"]")).click();
        cadastro.findElement(By.xpath("" +
                "/html/body/section/div/div/div/div/form/div[5]/div/div[1]/div/select/option[18]")).click();
        cadastro.findElement(By.xpath("" +
                "/html/body/section/div/div/div/div/form/div[5]/div/div[2]/div/select/option[7]")).click();
        cadastro.findElement(By.xpath("" +
                "/html/body/section/div/div/div/div/form/div[5]/div/div[3]/div/select/option[2]")).click();
        cadastro.findElement(By.id("newsletter")).click();
        cadastro.findElement(By.id("optin")).click();
        cadastro.findElement(By.id("first_name")).sendKeys("Alessandro");
        cadastro.findElement(By.id("last_name")).sendKeys("Oliveira");
        cadastro.findElement(By.id("address1")).sendKeys("Rua Rio Traíra, n 37");
        cadastro.findElement(By.xpath("" +
                "/html/body/section/div/div/div/div/form/p[6]/select/option[3]")).click();
        cadastro.findElement(By.id("state")).sendKeys("Amazonas");
        cadastro.findElement(By.id("city")).sendKeys("Manaus");
        cadastro.findElement(By.id("zipcode")).sendKeys("69086170");
        cadastro.findElement(By.id("mobile_number")).sendKeys("92991455763");
        //saindo do formulário
        navegador.findElement(By.xpath("/html/body/section/div/div/div/div/form/button")).click();
    }
    @AfterTest
    public void tearDown(){
        navegador.quit();
    }
}