import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import java.util.Random;

public class CriarPreCadastro {
    @Test
    public void firefoxTest(){
        //gerar número aleatório para o email
        Random gerarEmail = new Random();

        WebDriver navegador = new FirefoxDriver();
        navegador.get("https://automationexercise.com/login");

        //Criar formulário
        WebElement loginParaCriarUsuario = navegador.findElement(By.className("signup-form"));

        //Preencher o campo Nome
        loginParaCriarUsuario.findElement(By.name("name")).sendKeys("nomeCurso");

        //Preencher o campo Email
        loginParaCriarUsuario.findElement(By.name("email")).sendKeys("user_email_"+gerarEmail.nextInt(1001)+"@teste.com");

        //Clicar no botão signup
        navegador.findElement(By.xpath("/html/body/section/div/div/div[3]/div/form/button")).click();

        //fechar o navegador
        //navegador.quit();
    }
}
