import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class BeforeEAfter {
    private WebDriver navegador;

    @BeforeTest
    public void setUp(){
        navegador = new FirefoxDriver();
        navegador.get("https://automationexercise.com/login");
    }

    @Test
    public void firefoxTest(){
        //Criar formulário
        WebElement loginParaCriarUsuario = navegador.findElement(By.className("signup-form"));

        //Preencher o campo Nome
        loginParaCriarUsuario.findElement(By.name("name")).sendKeys("nomeCurso");

        //Preencher o campo Email
        loginParaCriarUsuario.findElement(By.name("email")).sendKeys("email.curso@teste.com");

        //Clicar no botão signup
        navegador.findElement(By.xpath("/html/body/section/div/div/div[3]/div/form/button")).click();

    }
    @AfterTest
    public void tearDown(){
        navegador.quit();
    }
}