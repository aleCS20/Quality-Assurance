package pages;

import org.openqa.selenium.WebDriver;
import static org.testng.AssertJUnit.assertTrue;

public class ContaCriada extends BasePage{
    public ContaCriada(WebDriver navegador) {
        super(navegador);

        assertTrue(navegador.getPageSource().contains("Account Created!"));
    }
}
