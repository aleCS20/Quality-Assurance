package suporte;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Web {

    public static WebDriver createFirefox(){
        WebDriver navegador = new FirefoxDriver();
        navegador.get("https://automationexercise.com/login");
        return navegador;
    }

}
