import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.PreCadastro;
import suporte.Web;

public class CadastroPageObject {

    private WebDriver navegador;

    @BeforeTest
    public void setUp(){
        navegador = Web.createFirefox();
    }
    @Test
    public void cadastro(){
        new PreCadastro(navegador)
                .login("testePaginaPreCadastro")
                .email("testeemail2@precadastro.com")
                .pagina()
                .genero()
                .senha("123456")
                .dia()
                .mes()
                .ano()
                .noticia()
                .opcao()
                .primeiroNome("Alessandro")
                .sobreNome("Oliveira")
                .rua("Rio Traira")
                .pais()
                .estado("Amazonas")
                .cidade("Manaus")
                .codigoPostal("69086170")
                .telefone("999999999")
                .pagina();
    }
    //@AfterTest
    public void tearDown(){
        navegador.quit();
    }
}
