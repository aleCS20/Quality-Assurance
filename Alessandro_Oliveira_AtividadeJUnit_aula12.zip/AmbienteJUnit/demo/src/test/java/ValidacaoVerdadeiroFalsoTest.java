import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ValidacaoVerdadeiroFalsoTest {
    @Test
    public void verdadeiro(){
        boolean campoEstaPresente = true;
        assertTrue(campoEstaPresente);
        System.out.println(campoEstaPresente);
    }
    @Test
    public void falso(){
        boolean campoEstaPresente = false;
        assertFalse(campoEstaPresente);
        System.out.println(campoEstaPresente);
    }
}
