import org.junit.Test;

public class MeuPrimeiroTesteTest {
    @Test
    public void teste01(){
        System.out.println("Teste 1 executado!");
    }

    public void teste02(){
        System.out.println("Teste 2 não executado!");
    }

    @Test
    public void teste03(){
        System.out.println("Teste 3 executado!");
    }
}
