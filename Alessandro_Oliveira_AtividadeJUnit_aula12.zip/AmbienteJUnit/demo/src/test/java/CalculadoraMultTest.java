import org.example.CalculadoraMult;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CalculadoraMultTest {
    CalculadoraMult calculo = new CalculadoraMult();
    @Test
    public void calc(){
       assertEquals(6, calculo.multiplicacao(3,2));
    }
}
