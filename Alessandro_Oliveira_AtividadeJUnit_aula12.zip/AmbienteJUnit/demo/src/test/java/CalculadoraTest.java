import org.example.Calculadora;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CalculadoraTest {
    Calculadora calculo = new Calculadora();

    @Test
    public void soma(){
        assertEquals(4, calculo.calc(2, 2));
    }
}
