import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PrePosCondicoesTesteTest {
    @Before
    public void preCondicao(){
        System.out.println("Pré Condição");
    }
    @Test
    public void metodo01(){
        System.out.println("Método 01");
    }
    @Test
    public void metodo02(){
        System.out.println("Método 02");
    }
    @After
    public void posCondicao(){
        System.out.println("Pós Condições");
    }
}
