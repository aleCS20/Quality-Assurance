package org.example;

public class CalculadoraMult {
    public int multiplicacao(int num1, int num2) {
        int mult = num1 * num2;
        return mult;
    }
}
