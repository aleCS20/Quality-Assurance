package org.example;

public class Calculadora {

    public int calc(int numero1, int numero2){
        int soma = numero1 + numero2;
        return soma;
    }
}
