import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class EfetuarLogin {

    @Test
    public void firefoxTest(){
        WebDriver navegador = new FirefoxDriver();
        navegador.get("https://the-internet.herokuapp.com/login");

        //criar formulário
        WebElement loginUsuario = navegador.findElement(By.id("login"));

        //preencher username
        loginUsuario.findElement(By.id("username")).sendKeys("tomsmith");

        //preencher password
        loginUsuario.findElement(By.id("password")).sendKeys("SuperSecretPassword!");

        //clicar no botão login
        navegador.findElement(By.xpath("/html/body/div[2]/div/div/form/button")).click();

        //navegador.quit();
    }
}
